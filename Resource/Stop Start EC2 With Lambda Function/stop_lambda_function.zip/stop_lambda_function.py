import boto3
import os
import json

def lambda_handler(event, context):
    try:
        tags = os.environ["Tags_json"]
        dictionary = json.loads(tags) # Convert str to Dictionary using Json
        print(dictionary)
        print(type(dictionary))

        ec2 = boto3.client('ec2')

        instance_ids = [] # Placeholder for instance ids
        
        for (key, value) in dictionary.items():
            print(f'Key: {key}')
            print(f'Value: {value}')
            
            NextToken = '' # Placeholder for NextToken
            
            # Describe instances with the specified tag key and value, limiting the response to 20 instances per call
            response = ec2.describe_instances(
                Filters=[
                    {'Name': 'tag-key', 'Values': [key]},
                    {'Name': 'tag-value', 'Values': [value]},
                    {'Name': 'instance-state-name', 'Values': ['running']}
                ],
                MaxResults=20
            )
            print(f'EC2 InstanceIds Response: {response}')
            
            # This loop fetches all the instance ids using pagination with NextToken
            while True:
                for reservation in response['Reservations']:
                    for instance in reservation['Instances']:
                        instance_ids.append(instance['InstanceId'])
                        print(f'Number of instances: {len(instance_ids)}')
                        print (f'instance_id: {instance_ids}')
                    
                # If NextToken is present, it retrieves the next set of instances
                if 'NextToken' in response:
                    print("Testing NextToken")
                    response = ec2.describe_instances(Filters=[{'Name': f'tag:{key}', 'Values': [value]}], NextToken=response['NextToken'])
                    print(f'Response: {response}')
                    print(f'NextToken: {NextToken}')
                else:
                    break
            
        if instance_ids:
            # Stop the instances
            ec2.stop_instances(InstanceIds=instance_ids)
            print("EC2 instances stopped: {}".format(instance_ids))
        else:
            print("No EC2 instances matching the filter.")
    
    except Exception as e:
        print("An error occurred:", str(e))
        # Add any specific error handling or logging logic here